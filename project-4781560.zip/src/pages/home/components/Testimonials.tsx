export default function Testimonials() {
  const testimonials = [
    '使用這個 AI 預測服務後,我的分析效率提升了 10 倍,不再需要花時間翻閱數據表格。',
    'AI 的預測準確率確實很高,特別是在五大聯賽的場次,信心指數高的預測命中率超過 80%。',
    'Telegram 群組每天準時推送預測,格式清晰易懂,還有詳細的數據解讀,非常專業。',
    '多模型集成的方法讓預測更加可靠,不會因為單一模型的偏差而影響判斷。',
    '賽前 30 小時的提醒非常及時,讓我有充足的時間做出決策,不用匆忙行動。',
    '專注於五大聯賽的策略很明智,質量遠勝於那些試圖覆蓋所有賽事的平台。'
  ];

  return (
    <section id="testimonials" className="py-24 bg-gray-50">
      <div className="max-w-7xl mx-auto px-6">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6" style={{ fontFamily: 'Noto Sans TC, sans-serif' }}>
            用戶評價
          </h2>
          <p className="text-xl text-gray-600">
            來自真實用戶的反饋和評價
          </p>
        </div>

        {/* Testimonials Banner Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {testimonials.map((testimonial, index) => (
            <div
              key={index}
              className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300 hover:-translate-y-1 border border-gray-100"
            >
              {/* Quote Icon */}
              <div className="mb-6">
                <i className="ri-double-quotes-l text-5xl text-emerald-500 opacity-30"></i>
              </div>

              {/* Stars */}
              <div className="flex gap-1 mb-6">
                {[...Array(5)].map((_, i) => (
                  <i key={i} className="ri-star-fill text-xl text-yellow-400"></i>
                ))}
              </div>

              {/* Content */}
              <p className="text-gray-700 leading-relaxed text-lg">
                {testimonial}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
