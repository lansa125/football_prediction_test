import { useState } from 'react';

export default function FAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const faqs = [
    {
      question: '預測準確率真的有 75% 嗎？',
      answer: '75% 是基於過去 6 個月在五大聯賽的測試結果，實際準確率會因聯賽、賽季階段而有波動。我們會持續追蹤並公開我們的預測記錄，確保透明度。'
    },
    {
      question: '服務完全免費嗎？',
      answer: 'Telegram 群組提供的基礎預測完全免費，包括每日賽事推送和基本分析。未來可能推出進階付費版本，提供更深入的數據分析和個性化建議。'
    },
    {
      question: '預測涵蓋哪些聯賽？',
      answer: '目前專注於英超、西甲、意甲、德甲、法甲等五大主流聯賽。我們選擇集中資源在這些數據最完整、最具代表性的聯賽上，以確保預測質量。'
    },
    {
      question: '如何加入 Telegram 群組？',
      answer: '點擊頁面上的「免費加入 Telegram 群組」按鈕，會直接跳轉到 Telegram 群組連結。如果你還沒有安裝 Telegram，需要先下載並註冊 Telegram 應用。'
    }
  ];

  return (
    <section id="faq" className="py-24 bg-white">
      <div className="max-w-4xl mx-auto px-6">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6" style={{ fontFamily: 'Noto Sans TC, sans-serif' }}>
            常見問題解答
          </h2>
          <p className="text-xl text-gray-600">
            關於我們服務的一切你需要知道的
          </p>
        </div>

        {/* FAQ List */}
        <div className="space-y-4">
          {faqs.map((faq, index) => (
            <div
              key={index}
              className="bg-white rounded-2xl shadow-md overflow-hidden hover:shadow-lg transition-shadow duration-300"
            >
              {/* Question */}
              <button
                onClick={() => setOpenIndex(openIndex === index ? null : index)}
                className="w-full px-8 py-6 flex items-center justify-between text-left cursor-pointer hover:bg-gray-50 transition-colors"
              >
                <h3 className="text-lg font-bold text-gray-900 pr-4">
                  {faq.question}
                </h3>
                <div className={`w-8 h-8 flex items-center justify-center flex-shrink-0 rounded-full bg-emerald-100 transition-transform duration-300 ${openIndex === index ? 'rotate-180' : ''}`}>
                  <i className="ri-arrow-down-s-line text-emerald-600 text-xl"></i>
                </div>
              </button>

              {/* Answer */}
              <div
                className={`overflow-hidden transition-all duration-300 ${
                  openIndex === index ? 'max-h-96' : 'max-h-0'
                }`}
              >
                <div className="px-8 pb-6">
                  <p className="text-gray-600 leading-relaxed">
                    {faq.answer}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
