export default function About() {
  const features = [
    {
      title: '深度數據挖掘',
      content: '我們的 AI 引擎同時分析球隊戰績、球員狀態、傷兵名單、天氣條件、賠率波動等多個維度,確保沒有遺漏任何關鍵因素。傳統分析師需要 2-3 小時的工作量,AI 瞬間完成。'
    },
    {
      title: '消除主觀偏見',
      content: '人的預測容易受情緒影響(偏好某支球隊、被最近的比賽結果帶偏),AI 則基於冷酷的數據。我們的多模型集成方法(泊松分佈、機器學習、深度神經網絡)交叉驗證,避免單一模型的誤差。'
    },
    {
      title: '每天節省 2 小時',
      content: '不再需要手動翻閱數據表、研究歷史戰績、追蹤傷兵情況。AI 自動完成所有分析,你只需花 5 分鐘瀏覽 Telegram 推送的預測結果。'
    },
    {
      title: '準確率提升 75%',
      content: '基於過去 6 個月的五大聯賽測試,我們的 AI 預測準確率達 75%,遠高於行業平均的 55%。信心指數高的預測命中率超過 80%。'
    }
  ];

  return (
    <section id="about" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-6">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6" style={{ fontFamily: 'Noto Sans TC, sans-serif' }}>
            我們如何用 AI 改變足球預測
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            傳統足球預測依賴球迷直覺和碎片化資訊,我們開發的專有 AI 引擎通過數據科學改變這一切。
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {features.map((feature, index) => (
            <div
              key={index}
              className="bg-gray-900/95 rounded-2xl p-8 border-l-4 border-emerald-500 hover:border-l-8 transition-all duration-300 hover:shadow-2xl"
            >
              <h3 className="text-2xl font-bold text-white mb-4" style={{ fontFamily: 'Noto Sans TC, sans-serif' }}>
                {feature.title}
              </h3>
              <p className="text-gray-300 leading-relaxed">
                {feature.content}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
