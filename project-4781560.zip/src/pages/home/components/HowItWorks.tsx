export default function HowItWorks() {
  const steps = [
    {
      number: '01',
      title: '數據收集',
      points: [
        '從官方或經授權的數據供應商獲取即時資料',
        '涵蓋五大聯賽及主要杯賽',
        '24/7 持續監控更新'
      ],
      icon: 'ri-database-2-line'
    },
    {
      number: '02',
      title: '特徵工程',
      points: [
        '提取多個預測特徵',
        '計算球隊攻防指數、近期狀態評分',
        '量化主客場優勢、球員影響力'
      ],
      icon: 'ri-settings-3-line'
    },
    {
      number: '03',
      title: 'AI 模型預測',
      points: [
        '泊松分佈預測比分',
        '機器學習模型計算勝平負概率',
        '深度神經網絡進行綜合判斷'
      ],
      icon: 'ri-brain-line'
    },
    {
      number: '04',
      title: '結果輸出',
      points: [
        '生成波膽（正確比分）預測',
        '提供 1X2（勝平負）建議',
        '計算信心指數與預期價值'
      ],
      icon: 'ri-file-chart-line'
    }
  ];

  return (
    <section id="how-it-works" className="py-24 bg-gray-900 text-white relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-20 left-10 w-72 h-72 bg-emerald-500 rounded-full blur-3xl"></div>
        <div className="absolute bottom-20 right-10 w-96 h-96 bg-emerald-600 rounded-full blur-3xl"></div>
      </div>

      <div className="max-w-7xl mx-auto px-6 relative z-10">
        {/* Section Header */}
        <div className="text-center mb-20">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6" style={{ fontFamily: 'Noto Sans TC, sans-serif' }}>
            我們的 AI 預測系統運作原理
          </h2>
          <p className="text-xl text-gray-400 max-w-3xl mx-auto">
            從數據收集到結果輸出，全程自動化的智能預測流程
          </p>
        </div>

        {/* Steps Flow */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {steps.map((step, index) => (
            <div key={index} className="relative">
              {/* Arrow Connector (Desktop) */}
              {index < steps.length - 1 && (
                <div className="hidden lg:block absolute top-20 -right-4 z-0">
                  <i className="ri-arrow-right-line text-4xl text-emerald-500/30"></i>
                </div>
              )}

              {/* Step Card */}
              <div className="relative z-10 bg-gray-800/50 backdrop-blur-sm rounded-2xl p-8 border border-gray-700 hover:border-emerald-500 transition-all duration-300 h-full">
                {/* Number Badge */}
                <div className="absolute -top-4 -left-4 w-12 h-12 bg-gradient-to-br from-emerald-500 to-emerald-600 rounded-full flex items-center justify-center shadow-lg shadow-emerald-500/50">
                  <span className="text-white font-bold text-sm">{step.number}</span>
                </div>

                {/* Icon */}
                <div className="w-16 h-16 bg-gray-700 rounded-xl flex items-center justify-center mb-6 mt-4">
                  <i className={`${step.icon} text-3xl text-emerald-400`}></i>
                </div>

                {/* Title */}
                <h3 className="text-2xl font-bold text-white mb-6">
                  {step.title}
                </h3>

                {/* Points */}
                <ul className="space-y-3">
                  {step.points.map((point, idx) => (
                    <li key={idx} className="flex items-start gap-3">
                      <div className="w-5 h-5 flex items-center justify-center flex-shrink-0 mt-0.5">
                        <i className="ri-check-line text-emerald-400 text-lg"></i>
                      </div>
                      <span className="text-gray-300 text-sm leading-relaxed">{point}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
