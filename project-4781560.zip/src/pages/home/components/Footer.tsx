export default function Footer() {
  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-gray-900 text-white">
      <div className="max-w-7xl mx-auto px-6 py-16">
        {/* Top Section */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 mb-12">
          {/* Brand */}
          <div className="md:col-span-1">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 bg-emerald-500 rounded-lg flex items-center justify-center">
                <i className="ri-football-line text-2xl text-white"></i>
              </div>
              <span className="text-xl font-bold" style={{ fontFamily: 'Orbitron, sans-serif' }}>足球預測AI</span>
            </div>
            <p className="text-gray-400 text-sm leading-relaxed">
              AI 驅動的足球預測平台,科學分析每一場比賽
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-bold mb-4">快速連結</h3>
            <ul className="space-y-3">
              <li>
                <button onClick={scrollToTop} className="text-gray-400 hover:text-emerald-400 transition-colors cursor-pointer">首頁</button>
              </li>
              <li>
                <button onClick={() => scrollToSection('about')} className="text-gray-400 hover:text-emerald-400 transition-colors cursor-pointer">關於我們</button>
              </li>
              <li>
                <button onClick={() => scrollToSection('benefits')} className="text-gray-400 hover:text-emerald-400 transition-colors cursor-pointer">為什麼選擇我們</button>
              </li>
              <li>
                <button onClick={() => scrollToSection('how-it-works')} className="text-gray-400 hover:text-emerald-400 transition-colors cursor-pointer">AI 原理</button>
              </li>
              <li>
                <button onClick={() => scrollToSection('testimonials')} className="text-gray-400 hover:text-emerald-400 transition-colors cursor-pointer">用戶評價</button>
              </li>
              <li>
                <button onClick={() => scrollToSection('faq')} className="text-gray-400 hover:text-emerald-400 transition-colors cursor-pointer">常見問題</button>
              </li>
            </ul>
          </div>

          {/* Contact & Telegram */}
          <div>
            <h3 className="text-lg font-bold mb-4">聯絡我們</h3>
            <ul className="space-y-3">
              <li>
                <a href="https://t.me/your_group_link" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-emerald-400 transition-colors inline-flex items-center gap-2 cursor-pointer">
                  <i className="ri-telegram-line"></i>
                  加入 Telegram 群組
                </a>
              </li>
              <li>
                <a href="mailto:contact@example.com" className="text-gray-400 hover:text-emerald-400 transition-colors inline-flex items-center gap-2">
                  <i className="ri-mail-line"></i>
                  電子郵件
                </a>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Section */}
        <div className="pt-8 border-t border-gray-800 flex flex-col md:flex-row justify-between items-center gap-4">
          <div className="text-gray-400 text-sm text-center md:text-left">
            © 2025 足球預測 AI | 本服務僅供數據參考,不構成投注建議
          </div>
          <div className="text-gray-400 text-sm">
            <a href="https://readdy.ai/?origin=logo" target="_blank" rel="noopener noreferrer" className="hover:text-emerald-400 transition-colors">Powered by Readdy</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
