import { useState, useEffect } from 'react';

export default function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setIsMobileMenuOpen(false);
    }
  };

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
    setIsMobileMenuOpen(false);
  };

  const navLinks = [
    { label: '首頁', id: 'home', action: scrollToTop },
    { label: '關於我們', id: 'about' },
    { label: '為什麼選擇我們', id: 'benefits' },
    { label: 'AI 原理', id: 'how-it-works' },
    { label: '用戶評價', id: 'testimonials' },
    { label: '常見問題', id: 'faq' }
  ];

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled ? 'bg-white shadow-lg' : 'bg-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex items-center justify-between h-20">
          {/* Logo */}
          <button
            onClick={scrollToTop}
            className="flex items-center gap-3 cursor-pointer"
          >
            <div className="w-10 h-10 bg-emerald-500 rounded-lg flex items-center justify-center">
              <i className="ri-football-line text-xl text-white"></i>
            </div>
            <span
              className={`text-xl font-bold transition-colors ${
                isScrolled ? 'text-gray-900' : 'text-white'
              }`}
              style={{ fontFamily: 'Orbitron, sans-serif' }}
            >
              足球預測AI
            </span>
          </button>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => (
              <button
                key={link.id}
                onClick={() => link.action ? link.action() : scrollToSection(link.id)}
                className={`text-sm font-medium transition-colors cursor-pointer whitespace-nowrap ${
                  isScrolled
                    ? 'text-gray-700 hover:text-emerald-500'
                    : 'text-white hover:text-emerald-400'
                }`}
              >
                {link.label}
              </button>
            ))}
            <a
              href="https://t.me/your_group_link"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-6 py-2.5 bg-emerald-500 hover:bg-emerald-600 text-white text-sm font-bold rounded-full transition-all duration-300 cursor-pointer whitespace-nowrap"
            >
              <i className="ri-telegram-line"></i>
              加入群組
            </a>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className={`md:hidden w-10 h-10 flex items-center justify-center cursor-pointer ${
              isScrolled ? 'text-gray-900' : 'text-white'
            }`}
          >
            <i className={`text-2xl ${isMobileMenuOpen ? 'ri-close-line' : 'ri-menu-line'}`}></i>
          </button>
        </div>

        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <div className="md:hidden bg-white border-t border-gray-200 py-4">
            {navLinks.map((link) => (
              <button
                key={link.id}
                onClick={() => link.action ? link.action() : scrollToSection(link.id)}
                className="block w-full text-left px-4 py-3 text-gray-700 hover:bg-gray-50 hover:text-emerald-500 transition-colors cursor-pointer"
              >
                {link.label}
              </button>
            ))}
            <a
              href="https://t.me/your_group_link"
              target="_blank"
              rel="noopener noreferrer"
              className="block mx-4 mt-4 text-center px-6 py-3 bg-emerald-500 hover:bg-emerald-600 text-white font-bold rounded-full transition-all duration-300 cursor-pointer"
            >
              <i className="ri-telegram-line mr-2"></i>
              加入群組
            </a>
          </div>
        )}
      </div>
    </nav>
  );
}
