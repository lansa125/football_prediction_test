export default function Benefits() {
  const benefits = [
    {
      icon: 'ri-time-line',
      title: '賽前 30 小時提醒',
      description: '大多數博彩公司在賽前 30 小時才開出完整賠率，我們在這個黃金窗口立即推送 AI 預測。',
      detail: '你有充足時間評估、尋求最佳賠率，而不是被迫匆忙決定。'
    },
    {
      icon: 'ri-trophy-line',
      title: '精選五大賽事',
      description: '我們不貪心，專注於英超、西甲、意甲、德甲、法甲五大聯賽。集中火力確保每場預測都經過充分數據驗證，質量優於試圖涵蓋所有賽事的工具。',
      detail: '每週推送數十場精挑細選的高品質預測。'
    },
    {
      icon: 'ri-shield-check-line',
      title: '可靠的預測',
      description: '我們不製造虛假準確率。基於 6 個月的實測數據，AI 預測準確率達 75%，遠高於行業平均 55%。',
      detail: '每個預測都配備信心指數，讓你知道 AI 對這場比賽有多「有把握」。'
    },
    {
      icon: 'ri-team-line',
      title: '交互式社群',
      description: 'Telegram 群組不只是單向推送，你可以與其他球迷討論預測邏輯、提出質疑、分享個人見解。',
      detail: '我們的分析師會定期回答問題，打造真正的預測社群。'
    }
  ];

  return (
    <section id="benefits" className="py-24 bg-gray-50">
      <div className="max-w-7xl mx-auto px-6">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6" style={{ fontFamily: 'Noto Sans TC, sans-serif' }}>
            為什麼選擇我們的 AI 預測
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            在眾多預測工具中，我們通過以下優勢脫穎而出。
          </p>
        </div>

        {/* Benefits Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {benefits.map((benefit, index) => (
            <div
              key={index}
              className="group bg-white rounded-2xl p-8 shadow-lg hover:shadow-2xl hover:-translate-y-2 transition-all duration-300"
            >
              {/* Icon */}
              <div className="w-16 h-16 bg-gradient-to-br from-emerald-500 to-emerald-600 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                <i className={`${benefit.icon} text-3xl text-white`}></i>
              </div>

              {/* Title */}
              <h3 className="text-xl font-bold text-gray-900 mb-4">
                {benefit.title}
              </h3>

              {/* Description */}
              <p className="text-gray-600 text-sm leading-relaxed mb-4">
                {benefit.description}
              </p>

              {/* Detail */}
              <p className="text-emerald-600 text-sm font-semibold">
                {benefit.detail}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
