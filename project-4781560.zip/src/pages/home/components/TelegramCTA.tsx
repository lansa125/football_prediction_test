export default function TelegramCTA() {
  const features = [
    { icon: 'ri-bar-chart-box-line', text: '每日五大聯賽預測推送' },
    { icon: 'ri-file-list-3-line', text: '賽事完整分析' },
    { icon: 'ri-flashlight-line', text: '賽前 30 小時提前通知' },
    { icon: 'ri-robot-line', text: '多模型集成驗證' }
  ];

  return (
    <section id="telegram-cta" className="py-24 bg-gradient-to-br from-blue-600 via-blue-700 to-blue-800 relative overflow-hidden">
      {/* Animated Background Elements */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-10 left-10 w-64 h-64 bg-white rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-10 right-10 w-96 h-96 bg-white rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }}></div>
      </div>

      {/* Geometric Decorations */}
      <div className="absolute top-20 right-20 w-32 h-32 border-4 border-white/20 rounded-full"></div>
      <div className="absolute bottom-20 left-20 w-24 h-24 border-4 border-white/20 rotate-45"></div>

      <div className="max-w-5xl mx-auto px-6 relative z-10 text-center">
        {/* Main Title */}
        <h2 className="text-4xl md:text-6xl font-bold text-white mb-6 leading-tight" style={{ fontFamily: 'Noto Sans TC, sans-serif' }}>
          立即加入我們的 Telegram 群組
        </h2>
        
        <p className="text-xl md:text-2xl text-blue-100 mb-12">
          開始接收每日免費 AI 預測
        </p>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {features.map((feature, index) => (
            <div
              key={index}
              className="flex flex-col items-center gap-3 p-6 bg-white/10 backdrop-blur-sm rounded-2xl border border-white/20 hover:bg-white/20 transition-all duration-300"
            >
              <div className="w-14 h-14 bg-white/20 rounded-full flex items-center justify-center">
                <i className={`${feature.icon} text-3xl text-white`}></i>
              </div>
              <span className="text-white font-semibold text-center">{feature.text}</span>
            </div>
          ))}
        </div>

        {/* CTA Button with Pulse Animation */}
        <div className="relative inline-block">
          {/* Pulse Rings */}
          <div className="absolute inset-0 rounded-full bg-white/30 animate-ping"></div>
          <div className="absolute inset-0 rounded-full bg-white/20 animate-pulse"></div>
          
          {/* Button */}
          <a
            href="https://t.me/your_group_link"
            target="_blank"
            rel="noopener noreferrer"
            className="relative inline-flex items-center gap-4 px-12 py-6 bg-white text-blue-700 text-xl font-bold rounded-full shadow-2xl hover:bg-blue-50 hover:scale-105 transition-all duration-300 cursor-pointer whitespace-nowrap"
          >
            <i className="ri-telegram-fill text-3xl"></i>
            免費加入 Telegram 群組
            <i className="ri-arrow-right-line text-2xl"></i>
          </a>
        </div>

        {/* Trust Badge */}
        <div className="mt-12 flex flex-wrap justify-center items-center gap-8 text-white/80">
          <div className="flex items-center gap-2">
            <i className="ri-shield-check-line text-2xl"></i>
            <span>100% 免費</span>
          </div>
          <div className="flex items-center gap-2">
            <i className="ri-user-line text-2xl"></i>
            <span>5,000+ 活躍成員</span>
          </div>
          <div className="flex items-center gap-2">
            <i className="ri-star-fill text-2xl text-yellow-300"></i>
            <span>4.9/5.0 評分</span>
          </div>
        </div>
      </div>
    </section>
  );
}
