export default function Hero() {
  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0 z-0">
        <img
          src="https://readdy.ai/api/search-image?query=dramatic%20night%20football%20stadium%20aerial%20view%20with%20bright%20green%20pitch%20illuminated%20by%20floodlights%2C%20dark%20atmospheric%20sky%2C%20cinematic%20sports%20photography%2C%20professional%20stadium%20from%20above%20showing%20perfect%20grass%20patterns%20and%20goal%20posts&width=1920&height=1080&seq=hero-bg-001&orientation=landscape"
          alt="Football Stadium"
          className="w-full h-full object-cover object-top"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/70 via-black/60 to-black/70"></div>
      </div>

      {/* Content */}
      <div className="relative z-10 max-w-4xl mx-auto px-6 text-center">
        {/* Main Title */}
        <h1 className="text-5xl md:text-7xl font-bold text-white mb-6 leading-tight" style={{ fontFamily: 'Noto Sans TC, sans-serif' }}>
          AI 足球預測引擎<br />
          <span className="text-emerald-400">每天推送精準分析</span>
        </h1>

        {/* Subtitle */}
        <p className="text-xl md:text-2xl text-gray-200 mb-12 leading-relaxed">
          加入 Telegram,快速獲取五大聯賽預測,準確率 75%
        </p>

        {/* CTA Button */}
        <a
          href="https://t.me/your_group_link"
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-3 px-10 py-5 bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-600 hover:to-emerald-700 text-white text-lg font-bold rounded-full shadow-2xl shadow-emerald-500/50 hover:scale-105 transition-all duration-300 cursor-pointer whitespace-nowrap"
        >
          <i className="ri-telegram-line text-2xl"></i>
          免費加入 Telegram 群組
          <i className="ri-arrow-right-line text-xl"></i>
        </a>

        {/* Trust Indicators */}
        <div className="mt-16 flex flex-wrap justify-center gap-8 md:gap-12">
          <div className="text-center">
            <div className="text-3xl md:text-4xl font-bold text-emerald-400 mb-1">75%</div>
            <div className="text-sm text-gray-300">預測準確率</div>
          </div>
          <div className="text-center">
            <div className="text-3xl md:text-4xl font-bold text-emerald-400 mb-1">24/7</div>
            <div className="text-sm text-gray-300">實時監控</div>
          </div>
          <div className="text-center">
            <div className="text-3xl md:text-4xl font-bold text-emerald-400 mb-1">5+</div>
            <div className="text-sm text-gray-300">五大聯賽覆蓋</div>
          </div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 z-10">
        <div className="flex flex-col items-center gap-2 animate-bounce">
          <span className="text-white text-sm">向下滾動</span>
          <i className="ri-arrow-down-line text-white text-2xl"></i>
        </div>
      </div>
    </section>
  );
}
